<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KurssController extends Controller
{
    //
    public function Index() {
        return response()->json('visi kursi');
    }

    public function store(Request $request)
    {
        // Validate the incoming request data
        $request->validate([
            'title' => 'required|string',
            'text' => 'required|string',
            'address' => 'required|string',
            'people' => 'required|integer',
        ]);

        dd('help.');
    }
}
